import customtkinter as ctk
import threading as th
import main
from main import holdVariable

buttonClicked = False

def buttonClick():
    global buttonClicked
    buttonClicked = True
    return


class MainWindow:
    def __init__(self) -> None:

        self.root = ctk.CTk()
        self.leftFrame = ctk.CTkFrame(master=self.root)
        self.rightFrame = ctk.CTkFrame(master=self.root)
        
        self.codeTitleLabel = ctk.CTkLabel(master=self.leftFrame, text="ASM Code")
        self.codeLabel = ctk.CTkTextbox(master=self.leftFrame, wrap="word")

        self.registerTitleLabel = ctk.CTkLabel(master=self.rightFrame, text="Register Contents")
        self.registerLabel = ctk.CTkLabel(master=self.rightFrame)

        self.var = ctk.IntVar()

        self.raxFrame = ctk.CTkFrame(master=self.rightFrame)
        self.raxLabel = ctk.CTkLabel(master=self.raxFrame, text = 'rax')

        self.stepButton = ctk.CTkButton(master=self.rightFrame, text="Click me!", command=buttonClick)
        pass


window = MainWindow()

def makeWindow() -> MainWindow:
    
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")

    window.root.geometry("720x540")

    program_code = ''
    filePath = "../asm/asmFile.asm"

    with open(filePath, "r") as file:
        program_code = file.read()
            
    # Left side of window, contains code
    window.leftFrame.pack(side="left", pady=12, padx=10, fill="both", expand=True)

    # Right side of window, contains register contents
    window.rightFrame.pack(side="right", pady=12, padx=10, fill="both", expand=True)

    # Label for code
    window.codeTitleLabel.pack(pady=12, padx=10)

    # Label for ASM Code
    window.codeLabel.insert("1.0", program_code)
    window.codeLabel.pack(expand=True, fill="both")

    # Label for reg contents
    window.registerTitleLabel.pack(pady=12, padx=10)

    # Label for registers
    window.registerLabel.pack(pady=12, padx=10)

    # Button to move forward
    # window.stepButton.bind('<Button-1>', buttonClick)
    window.stepButton.pack(side="bottom")


    window.raxFrame.pack(side='left', padx=10, pady=12, expand=False)
    window.raxLabel.pack()

    

    new_values = {'rax': 10, 'rbx': 20, 'rcx': 30, 'rdx': 40, 'rsp': 50, 'rbp': 60, 'rsi': 70, 'rdi': 80}

    stringToDisplay = "\n".join([f"{reg}  =  {val}" for reg, val in new_values.items()])

    window.registerLabel.configure(text = stringToDisplay)

    return window


def renderWindow(window):
    window.root.mainloop()


def waitForButtonClick():

    global buttonClicked
    
    if buttonClicked == False:
        return False
    else:
        buttonClicked = False
        return True



def updateValues(cpu):

    registerContents = {
        'rax': 0,
        'rbx': 0,
        'rcx': 0,
        'rdx': 0,
        'rsp': 0,
        'rbp': 0,
        'rsi': 0,
        'rdi': 0
    }

    # Get values from CPU
    for key in registerContents.keys():
        registerContents[key] = getattr(cpu, key)

    stringToDisplay = "\n".join([f"{reg}  =  {val}" for reg, val in registerContents.items()])

    window.registerLabel.configure(text = stringToDisplay)

    window.root.update()
