# Register Watch

A basic Assembly debugger meant for x86_64 architecture.
This is meant mostly as an educational resource, aimed at students who are learning assembly programming

As of now, only basic instructions will be covered, such as mov, add, sub, cmp, etc.